ImmersiveDialogue v2.0.1 for S.T.A.L.K.E.R. 2: Heart of Chornobyl
Free movement, look and walking animation during NPC dialogue. No UE4SS required.

INSTALL (manual)
  Copy the three files
      zzz_ImmersiveDialogue_20_P.pak
      zzz_ImmersiveDialogue_20_P.ucas
      zzz_ImmersiveDialogue_20_P.utoc
  into
      <game>\Stalker2\Content\Paks\~mods\
  (create the ~mods folder if it does not exist). Keep the three names identical
  apart from the extension; the "_20_P" suffix makes the game load this pak above
  other mods, which it needs to do.

INSTALL (Vortex)
  Drop the zip into Vortex and deploy. No load-order step is needed.

UNINSTALL
  Delete the three files.

RECOMMENDED COMPANION
  This mod does not change the dialogue FOV zoom. Pair it with a Nexus
  "No Dialogue Zoom" pak (mods 71, 1499 or 1933) if you want that gone too.

COMPATIBILITY
  Overrides three game assets: AnimBP_Player, BP_Stalker2Character, IMC_Dialog.
  No config files. Any other mod that overrides the same assets will be
  overridden by this one.

Source and build instructions: https://github.com/noahsemus/stalker2-immersive-dialogue
