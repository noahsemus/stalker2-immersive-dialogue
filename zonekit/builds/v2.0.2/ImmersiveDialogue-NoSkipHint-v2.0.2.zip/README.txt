ImmersiveDialogue - No Skip Hint v2.0.2 (optional add-on)
Hides the "press X to skip" prompt in dialogue. With ImmersiveDialogue's free
look, moving or looking around kept making it pop up. The skip key still works.

INSTALL (manual)
  Copy the three files
      zzz_ImmersiveDialogueNoSkipHint_20_P.pak
      zzz_ImmersiveDialogueNoSkipHint_20_P.ucas
      zzz_ImmersiveDialogueNoSkipHint_20_P.utoc
  into
      <game>\Stalker2\Content\Paks\~mods\
  next to the main mod's files. Keep the three names identical apart from the
  extension.

INSTALL (Vortex)
  Drop the zip into Vortex and deploy.

UNINSTALL
  Delete the three files. The prompt comes back.

COMPATIBILITY
  Overrides one UI widget (W_SkipHintView). Works with or without the main mod.

Source and build instructions: https://github.com/noahsemus/stalker2-immersive-dialogue
