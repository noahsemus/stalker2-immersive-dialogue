ImmersiveDialogue v2.0.2 for S.T.A.L.K.E.R. 2: Heart of Chornobyl
Free movement, look and walking animation during NPC dialogue. No UE4SS required.

WHAT IS IN THIS ZIP
  Main\                  the mod itself (required)
      zzz_ImmersiveDialogue_20_P.pak / .ucas / .utoc
  Optional-NoSkipHint\   optional add-on: hides the "press X to skip" prompt in
      zzz_ImmersiveDialogueNoSkipHint_20_P.pak / .ucas / .utoc
                         dialogue (with free look, moving or looking around kept
                         making it pop up). The skip key still works without it.

INSTALL (Vortex)
  Drop the zip into Vortex. Because the zip holds more than one pak, Vortex
  lists the six files and asks which to install:
    - tick the three zzz_ImmersiveDialogue_20_P files for the mod alone, or
    - "Install All" for the mod plus the no-skip-prompt add-on.
  Deploy. Done. To change your choice later, reinstall the mod from the zip.

INSTALL (manual)
  Copy the three files from Main\ (and, if you want the add-on, the three from
  Optional-NoSkipHint\) into
      <game>\Stalker2\Content\Paks\~mods\
  (create the ~mods folder if it does not exist). Keep each set of three names
  identical apart from the extension; the "_20_P" suffix makes the game load
  these paks above other mods, which they need.

UNINSTALL
  Delete the files you copied.

RECOMMENDED COMPANION
  This mod does not change the dialogue FOV zoom. Pair it with a Nexus
  "No Dialogue Zoom" pak (mods 71, 1499 or 1933) if you want that gone too.

COMPATIBILITY
  Overrides three game assets: AnimBP_Player, BP_Stalker2Character, IMC_Dialog
  (the add-on overrides one UI widget, W_SkipHintView). No config files. Any
  other mod that overrides the same assets will be overridden by this one.

Source and build instructions: https://github.com/noahsemus/stalker2-immersive-dialogue
