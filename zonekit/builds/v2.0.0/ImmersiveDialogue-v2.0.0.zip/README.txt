ImmersiveDialogue v2.0.0 for S.T.A.L.K.E.R. 2: Heart of Chornobyl
Free movement, look and walking animation during NPC dialogue. No UE4SS required.

INSTALL (manual)
  Copy the three files
      zzz_ImmersiveDialogue_20_P.pak
      zzz_ImmersiveDialogue_20_P.ucas
      zzz_ImmersiveDialogue_20_P.utoc
  into
      <game>\Stalker2\Content\Paks\~mods\
  (create the ~mods folder if it does not exist). Keep the three names identical
  apart from the extension; the "_20_P" suffix makes the game load this pak above
  other mods, which it needs to do.

INSTALL (Vortex)
  Drop the zip into Vortex and deploy. No load-order step is needed.

UNINSTALL
  Delete the three files.

COMPATIBILITY
  Overrides three game assets: AnimBP_Player, BP_Stalker2Character, IMC_Dialog
  (plus CoreVariables.cfg for the dialogue FOV). Any other mod that overrides the
  same assets will be overridden by this one.

Source and build instructions: https://github.com/noahsemus/stalker2-immersive-dialogue
